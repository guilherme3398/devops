function pegaTopAleatorio(){
    var alturaPai = $('.container').height();
    return Math.random() * (alturaPai - $('.datenow-box').height());
}

function pegaLeftAleatorio(){
    var larguraPai = $('.container').width();
    return Math.random() * (larguraPai - $('.datenow-box').width());
}

function mostraHora() {
    var now = new Date();
    
    $('#curdate').html(now.toLocaleTimeString());
    $('.datenow-box').css('top', pegaTopAleatorio());
    $('.datenow-box').css('left', pegaLeftAleatorio());
    $('.datenow-box').css('visibility', 'visible');
}

$(function(){
    $('#btnMostraHora').click(function(){ mostraHora(); }); 
});